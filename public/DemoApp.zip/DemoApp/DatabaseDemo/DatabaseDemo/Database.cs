﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseDemo
{
    internal class Database
    {
        private String _connectionString = "";
        private MySqlConnection? _connection;
        public Database(String server="localhost", String port="3306" ,String user="root", String password="root", String database="")
        {
            _connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=None;server={0};port={1};user id={2};" +
    " password={3}; database={4} ;", server, port, user, password, database);
        }
        public void Open()
        {
            Close();
            _connection = new MySqlConnection(_connectionString);
            _connection.Open();
        }
        public void Close() 
        {
            if (_connection != null)
            {
                _connection.Close();
            }
        }
        public object ExectureScalar(String sql, Dictionary<String, Object>? parameters)
        {
            var command = new MySqlCommand(sql, _connection);
            if (parameters != null)
            {
                foreach (KeyValuePair<String, Object> kvp in parameters)
                {
                    parameters.Add(kvp.Key, kvp.Value);
                }
            }
            return command.ExecuteScalar();
        }
        public void ExecuteNonQuery(String sql, Dictionary<String, Object>? parameters)
        {
            var command = new MySqlCommand(sql, _connection);
            if (parameters != null)
            {
                foreach (KeyValuePair<String, Object> kvp in parameters)
                {
                    command.Parameters.Add(new MySqlParameter(kvp.Key, kvp.Value));
                }
            }
            command.ExecuteNonQuery();            
        }
        public MySqlDataReader ExecuteReader(String sql, Dictionary<String, Object>? parameters) 
        { 
            var command = new MySqlCommand(sql,_connection);
            if (parameters != null)
            {
                foreach(KeyValuePair<String, Object> kvp in parameters)
                {
                    parameters.Add(kvp.Key, kvp.Value);
                }
            }
            return command.ExecuteReader();
        }
        
    }
}
