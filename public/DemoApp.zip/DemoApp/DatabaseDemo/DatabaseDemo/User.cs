﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseDemo
{
    internal class User
    {
        private Database? _db = null;
        public int Id { get; set; }
        public String? Name { get; set; }
        public String? Email { get; set; }
        
        public User(int id,String name, String email) 
        {
            Id = id;
            Name = name;
            Email = email;
        }
        public User(Database db)
        {
            _db = db;   
        }        
        public void AddUser(String name, String email)
        {
            _db?.Open();
            _db?.ExecuteNonQuery("INSERT IGNORE INTO users(name,email) VALUES (@name, @email);",new Dictionary<string, object> { { "name", name }, { "email", email } });
            _db?.Close();
        }
        public void UpdateUser(int id, String email)
        {
            _db?.Open();
            _db?.ExecuteNonQuery("UPDATE users SET email = @email WHERE id = @id;", new Dictionary<string, object> { { "id", id }, { "email", email } });
            _db?.Close();
        }
        public void DeleteUser(int id) 
        {
            _db?.Open();
            _db?.ExecuteNonQuery("DELETE FROM users WHERE id = @id;", new Dictionary<string, object> { { "id", id } });
            _db?.Close();
        }
        public List<User> GetUsers() 
        {
            var users = new List<User>();
            _db?.Open();
            var reader = _db?.ExecuteReader("SELECT * FROM users;", null);
            while (reader!=null && reader.Read())
            {
                
                int id = reader.GetInt32("id");                
                string name = reader.GetString("name"); 
                string email = reader.GetString("email");
                var user = new User(id, name, email);                
                users.Add(user);
            }
            _db?.Close();
            return users;
        }
        public User? GetUser(int id)
        {
            User? user = null;
            _db?.Open();
            var reader = _db?.ExecuteReader("SELECT FROM users WHERE id = @id;", new Dictionary<string, object>() { { "id", id } });
            while (reader != null && reader.Read())
            {
                int i = reader.GetInt32("id");
                string name = reader.GetString("name");
                string email = reader.GetString("email");
                user = new User(i, name, email);                
            }
            _db?.Close();
            return user;
        }
    }
}
