﻿using DatabaseDemo;
using MySql.Data.MySqlClient;
using System.Data;
using System.Data.SqlClient;

String server = "127.0.0.1";
String database = "classicmodels";
String user = "root";
String password = "root";
String port = "3306";
String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};"+
    " password={3}; database={4} ;", server, port, user, password, database);


void CreateDatabase()
{
    String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};" +
        " password={3};", server, port, user, password);
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = "CREATE DATABASE IF NOT EXISTS shop_db";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    cmd.ExecuteNonQuery();
    conn.Close();
}
void DropTables()
{
    String database = "shop_db";
    String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};" +
        " password={3}; database={4}", server, port, user, password, database);
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = @"DROP TABLE IF EXISTS users;DROP TABLE IF EXISTS products;";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    cmd.ExecuteNonQuery();
    conn.Close();
}
void CreateTables()
{
    String database = "shop_db";
    String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};" +
        " password={3}; database={4}", server, port, user, password, database);
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = @"CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS products (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(200) NOT NULL,
                price DECIMAL(10, 2) NOT NULL,
                stock INT DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    cmd.ExecuteNonQuery();
    conn.Close();
}
void InsertTable()
{
    String database = "shop_db";
    String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};" +
        " password={3}; database={4}", server, port, user, password, database);
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = @"INSERT IGNORE INTO users (name, email) VALUES('Krit Chomaitong','krit.c@rumail.ru.ac.th')";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    cmd.ExecuteNonQuery();
    conn.Close();
}
void UpdateTable()
{
    String database = "shop_db";
    String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};" +
        " password={3}; database={4}", server, port, user, password, database);
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = @"UPDATE users SET email = 'krit.c@ru.ac.th' WHERE id = 1;";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    cmd.ExecuteNonQuery();
    conn.Close();
}
void DeleteTable()
{
    String database = "shop_db";
    String connectionString = String.Format("AllowPublicKeyRetrieval=True;SslMode=none;server={0};port={1};user id={2};" +
        " password={3}; database={4}", server, port, user, password, database);
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = @"DELETE FROM users WHERE id = 1;";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    cmd.ExecuteNonQuery();
    conn.Close();
}
void GetAllOrderDetails()
{
    MySqlConnection conn = new MySqlConnection(connectionString);
    conn.Open();
    String sql = "SELECT * FROM  classicmodels.orderdetails as o LIMIT 5";
    MySqlCommand cmd = new MySqlCommand(sql, conn);
    MySqlDataReader reader = cmd.ExecuteReader();
    Console.WriteLine("OrderNumber\tProductCode\tQuantity Ordered\tPrice Each\tOrder Line Number");
    while (reader.Read())
    {
        Console.WriteLine($"{reader["orderNumber"]}\t\t{reader["productCode"]}\t\t{reader["quantityOrdered"]}" +
            $"\t\t{reader["priceEach"]}\t\t{reader["orderLineNumber"]}");
    }
    conn.Close();
}
CreateDatabase();
DropTables();
CreateTables();
//InsertTable();
//UpdateTable();
//DeleteTable();
//GetAllOrderDetails();


var db = new Database(database:"shop_db");
var us = new User(db);
us.AddUser("Krit Chomaitong", "krit.c@ru.ac.th");
var users = us.GetUsers();
foreach (var u in users)
{
    Console.WriteLine($"Id = {u.Id}, Name = {u.Name}, Email = {u.Email}");
}


